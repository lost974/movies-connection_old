-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Sam 26 Février 2011 à 17:17
-- Version du serveur: 5.1.37
-- Version de PHP: 5.2.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `lost974`
--
CREATE DATABASE `lost974` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `lost974`;

-- --------------------------------------------------------

--
-- Structure de la table `mc_critiques`
--

CREATE TABLE `mc_critiques` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `critique` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `created` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `mc_critiques`
--

INSERT INTO `mc_critiques` VALUES(1, 1, 7, 'J''ai bien aimer ce film, beau film, avec une fin inattendue. On s''accroche aux personnages facilement, on évoluent avec eux. Un titre un poil spoileur, mais a la hauteur de l''intrigue de fin. Juste un conseil si vous ne l''avez pas vu, aller le voir ! ;-)', 1298135630);
INSERT INTO `mc_critiques` VALUES(2, 1, 8, 'Bon film, a voir absolument !! ', 1298201531);

-- --------------------------------------------------------

--
-- Structure de la table `mc_events`
--

CREATE TABLE `mc_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `arguments` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=30 ;

--
-- Contenu de la table `mc_events`
--

INSERT INTO `mc_events` VALUES(5, 1, 1, 5);
INSERT INTO `mc_events` VALUES(6, 1, 1, 6);
INSERT INTO `mc_events` VALUES(7, 2, 1, 7);
INSERT INTO `mc_events` VALUES(8, 2, 1, 8);
INSERT INTO `mc_events` VALUES(9, 2, 1, 9);
INSERT INTO `mc_events` VALUES(10, 1, 1, 10);
INSERT INTO `mc_events` VALUES(11, 1, 1, 11);
INSERT INTO `mc_events` VALUES(12, 2, 1, 12);
INSERT INTO `mc_events` VALUES(13, 2, 1, 13);
INSERT INTO `mc_events` VALUES(18, 2, 2, 3);
INSERT INTO `mc_events` VALUES(19, 1, 2, 7);
INSERT INTO `mc_events` VALUES(22, 1, 3, 1);
INSERT INTO `mc_events` VALUES(23, 1, 3, 4);
INSERT INTO `mc_events` VALUES(24, 1, 1, 16);
INSERT INTO `mc_events` VALUES(25, 1, 4, 2);
INSERT INTO `mc_events` VALUES(26, 1, 3, 5);
INSERT INTO `mc_events` VALUES(27, 1, 1, 17);
INSERT INTO `mc_events` VALUES(28, 1, 3, 6);
INSERT INTO `mc_events` VALUES(29, 1, 1, 18);

-- --------------------------------------------------------

--
-- Structure de la table `mc_friends`
--

CREATE TABLE `mc_friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Contenu de la table `mc_friends`
--

INSERT INTO `mc_friends` VALUES(3, 1, 2, 1, 1297506014);
INSERT INTO `mc_friends` VALUES(7, 2, 1, 1, 1297506014);

-- --------------------------------------------------------

--
-- Structure de la table `mc_maintenances`
--

CREATE TABLE `mc_maintenances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `open` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `mc_maintenances`
--

INSERT INTO `mc_maintenances` VALUES(1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `mc_marks`
--

CREATE TABLE `mc_marks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `mark` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `movie_id` (`movie_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Contenu de la table `mc_marks`
--

INSERT INTO `mc_marks` VALUES(5, 1, 4, 5, 1295284011, 0);
INSERT INTO `mc_marks` VALUES(6, 1, 3, 3, 1295284469, 0);
INSERT INTO `mc_marks` VALUES(7, 2, 6, 3, 1295545732, 0);
INSERT INTO `mc_marks` VALUES(8, 2, 5, 3, 1295545739, 0);
INSERT INTO `mc_marks` VALUES(9, 2, 3, 1, 1295545746, 0);
INSERT INTO `mc_marks` VALUES(10, 1, 7, 5, 1295678058, 0);
INSERT INTO `mc_marks` VALUES(11, 1, 6, 2, 1296410615, 0);
INSERT INTO `mc_marks` VALUES(12, 2, 7, 5, 1296496084, 0);
INSERT INTO `mc_marks` VALUES(13, 2, 4, 3, 1296496103, 0);
INSERT INTO `mc_marks` VALUES(16, 1, 8, 5, 1298201515, 0);
INSERT INTO `mc_marks` VALUES(17, 1, 1, 1, 1298716627, 0);
INSERT INTO `mc_marks` VALUES(18, 1, 5, 4, 1298716647, 0);

-- --------------------------------------------------------

--
-- Structure de la table `mc_movies`
--

CREATE TABLE `mc_movies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `release` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `synopsis` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `b_a` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Contenu de la table `mc_movies`
--

INSERT INTO `mc_movies` VALUES(1, 'Piranha 3D', '1.jpg', '1 septembre 2010 ', 'Alors que la ville de Lake Victoria s''apprête à recevoir des milliers d''étudiants pour le week-end de Pâques, un tremblement de terre secoue la ville et ouvre, sous le lac, une faille d''où des milliers de piranhas s''échappent. Inconscients du danger qui les guette, tous les étudiants font la fête sur le lac tandis que Julie, la shérif, découvre un premier corps dévoré... La journée va être d''autant plus longue pour elle que Jake, son fils, a délaissé la garde de ses jeunes frères et sœurs pour servir de guide à bord du bateau des sexy Wild Wild Girls !', '0');
INSERT INTO `mc_movies` VALUES(3, 'Easy A', '3.jpg', '5 janvier 2011', 'Une étudiante "accusée" d''avoir perdu sa virginité, se sert de la rumeur pour devenir populaire: elle se fait ainsi passer pour la "garce" de sa fac.', '0');
INSERT INTO `mc_movies` VALUES(4, 'Avatar', '4.jpg', '16 décembre 2009', 'Malgré sa paralysie, Jake Sully, un ancien marine immobilisé dans un fauteuil roulant, est resté un combattant au plus profond de son être. Il est recruté pour se rendre à des années-lumière de la Terre, sur Pandora, où de puissants groupes industriels exploitent un minerai rarissime destiné à résoudre la crise énergétique sur Terre. Parce que l''atmosphère de Pandora est toxique pour les humains, ceux-ci ont créé le Programme Avatar, qui permet à des " pilotes " humains de lier leur esprit à un avatar, un corps biologique commandé à distance, capable de survivre dans cette atmosphère létale. Ces avatars sont des hybrides créés génétiquement en croisant l''ADN humain avec celui des Na''vi, les autochtones de Pandora.\nSous sa forme d''avatar, Jake peut de nouveau marcher. On lui confie une mission d''infiltration auprès des Na''vi, devenus un obstacle trop conséquent à l''exploitation du précieux minerai. Mais tout va changer lorsque Neytiri, une très belle Na''vi, sauve la vie de Jake...', '0');
INSERT INTO `mc_movies` VALUES(5, 'Iron Man 2', '5.jpg', '28 avril 2010', 'Le monde sait désormais que l''inventeur milliardaire Tony Stark et le super-héros Iron Man ne font qu''un. Malgré la pression du gouvernement, de la presse et du public pour qu''il partage sa technologie avec l''armée, Tony n''est pas disposé à divulguer les secrets de son armure, redoutant que l''information atterrisse dans de mauvaises mains. Avec Pepper Potts et James "Rhodey" Rhodes à ses côtés, Tony va forger de nouvelles alliances et affronter de nouvelles forces toutes-puissantes...', '0');
INSERT INTO `mc_movies` VALUES(6, 'Percy Jackson, le voleur de foudre', '6.jpg', '10 février 2010 ', 'Un jeune homme découvre qu''il est le descendant d''un dieu grec et s''embarque, avec l''aide d''un satyre et de la fille d''Athena, dans une dangereuse aventure pour résoudre une guerre entre dieux. Sur sa route, il devra affronter une horde d''ennemis mythologiques bien décidés à le stopper.', '0');
INSERT INTO `mc_movies` VALUES(7, 'Remember Me', '7.jpg', '7 avril 2010 ', 'Tyler est un jeune New-yorkais de 22 ans en rébellion contre sa famille et la société suite à un drame familial. Après une altercation avec un policier, il décide de se venger en séduisant la fille de celui-ci. Mais Ally se révèle être une jeune fille fragile et imprévisible dont il va tomber fou amoureux. Ce qui ne devait être qu''une plaisanterie cruelle se transforme vite en une histoire qui les marquera à jamais...', '0');
INSERT INTO `mc_movies` VALUES(8, 'Tron l''héritage', '8.jpg', '9 février 2011 ', 'Sam Flynn, 27 ans, est le fils expert en technologie de Kevin Flynn. Cherchant à percer le mystère de la disparition de son père, il se retrouve aspiré dans ce même monde de programmes redoutables et de jeux mortels où vit son père depuis 25 ans. Avec la fidèle confidente de Kevin, père et fils s''engagent dans un voyage où la mort guette, à travers un cyber univers époustouflant visuellement, devenu plus avancé technologiquement et plus dangereux que jamais...', 'http://www.youtube.com/embed/McBX6r7UFwE');

-- --------------------------------------------------------

--
-- Structure de la table `mc_moviesaws`
--

CREATE TABLE `mc_moviesaws` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `mc_moviesaws`
--

INSERT INTO `mc_moviesaws` VALUES(1, 1, 7, 1298200844);
INSERT INTO `mc_moviesaws` VALUES(2, 1, 8, 1298201486);
INSERT INTO `mc_moviesaws` VALUES(3, 1, 8, 1298201501);
INSERT INTO `mc_moviesaws` VALUES(4, 1, 8, 1298201511);
INSERT INTO `mc_moviesaws` VALUES(5, 1, 1, 1298716622);
INSERT INTO `mc_moviesaws` VALUES(6, 1, 5, 1298716643);

-- --------------------------------------------------------

--
-- Structure de la table `mc_news`
--

CREATE TABLE `mc_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `created` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `mc_news`
--

INSERT INTO `mc_news` VALUES(1, 'Passage a la Beta', '0.1', 'Le site passe en version Beta. Le squelette est fini, et maintenant il ne reste plus qu''a ajouter quelques fonctionnalités. Le site profite aussi d''un nouveau design. Merci de m''aider a améliorer le site et a me reporter les bugs ou des suggestion a cette adresse : movieconnection.lost974@gmail.com', 1294136856, 1296485784);

-- --------------------------------------------------------

--
-- Structure de la table `mc_users`
--

CREATE TABLE `mc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `moderateur` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `mc_users`
--

INSERT INTO `mc_users` VALUES(1, 'Lost974', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'lost974.kevin@gmail.com', 2);
INSERT INTO `mc_users` VALUES(2, 'user1', 'b3daa77b4c04a9551b8781d03191fe098f325e67', 'user1@gmail.com', 0);
INSERT INTO `mc_users` VALUES(3, 'Meera974', '0b095082e445c2ea82014a5f9d9a9425a3b6a2b2', 'anne.ananda@live.fr', 0);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `mc_events`
--
ALTER TABLE `mc_events`
  ADD CONSTRAINT `mc_events_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `mc_users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `mc_marks`
--
ALTER TABLE `mc_marks`
  ADD CONSTRAINT `mc_marks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `mc_users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `mc_marks_ibfk_2` FOREIGN KEY (`movie_id`) REFERENCES `mc_movies` (`id`) ON DELETE CASCADE;
